


$(function() {  
    $(".inbox-chat-list").niceScroll({
        cursorcolor:"transparent",
        cursorborder: "none",
    });
});