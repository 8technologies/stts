$(document).ready(function() {
    $("#chat-emoji").emojioneArea();
});