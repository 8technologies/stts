
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo e(config('admin.title'), false); ?> | <?php echo e(trans('admin.login'), false); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 
  
  <?php if(!is_null($favicon = Admin::favicon())): ?>
  <link rel="shortcut icon" href="<?php echo e($favicon, false); ?>">
  <?php endif; ?>

  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/bootstrap/css/bootstrap.min.css'), false); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(admin_asset('vendor/laravel-admin/font-awesome/css/font-awesome.min.css'), false); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/dist/css/AdminLTE.min.css'), false); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/plugins/iCheck/square/blue.css'), false); ?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="//oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif] -->

  <style>
    input[type="text"]{
      border-radius: 5px;
      color: #008140;
    }
    
    input[type="password"]{
      border-radius: 5px;
      color: #008140;
    }

  </style>

</head>
<body class="hold-transition login-page" style="background: url(<?php echo e(asset('/assets/images/bg/background2.jpg'), false); ?>) no-repeat;background-size: cover;">
<div class="login-box">
   

  <!-- /.login-logo -->
  <div class="login-box-body" style="border-radius: 25px">
  <div class="login-logo">
    <a href="<?php echo e(admin_url('/'), false); ?>"><b><?php echo e(config('admin.name'), false); ?> Reset Password</b></a>
  <hr>
  </div>
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('message'), false); ?>

  </div>
  <?php elseif(session()->has('error')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('error'), false); ?>

  </div>
    <?php endif; ?>
    <!-- <p class="login-box-msg"><?php echo e(trans('admin.login'), false); ?></p> -->

    <form method="POST" action="<?php echo e(url('password/reset'), false); ?>">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address'), false); ?></label>

            <div class="col-md-6">
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email'), false); ?>" required autocomplete="email" autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message, false); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4" style="text-align:center">
                <button type="submit" class="btn btn-primary" >
                    <?php echo e(__('Send Password Reset Link'), false); ?>

                </button>
            </div>
        </div>
    </form>
    <div class="form-group text-end">
        <a href="<?php echo e(url('admin/auth/login'), false); ?>" class="nav-link"> Back to Login</a>
    </div>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.1.4 -->
<script src="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/plugins/jQuery/jQuery-2.1.4.min.js'), false); ?>"></script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/bootstrap/js/bootstrap.min.js'), false); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(admin_asset('vendor/laravel-admin/AdminLTE/plugins/iCheck/icheck.min.js'), false); ?>"></script>

<script>
     
    
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>

<?php /**PATH C:\Users\HP ENVY\Desktop\stts - Copy\resources\views/auth/forgetPassword.blade.php ENDPATH**/ ?>