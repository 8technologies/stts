<style>
    .title {
        font-size: 50px;
        color: #636b6f;
        font-family: 'Raleway', sans-serif;
        font-weight: 100;
        display: block;
        text-align: center;
        margin: 20px 0 10px 0px;
    }

    .links {
        text-align: center;
        margin-bottom: 20px;
    }

    .links > a {
        color: #636b6f;
        padding: 0 25px;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: .1rem;
        text-decoration: none;
        text-transform: uppercase;
    }
</style>

<div class="title">
    The National Seed Tracking & Tracing System Uganda 
</div>
<div class="links">
    <a href="javascript:;" >About Us</a>
    <a href="javascript:;"  >8Tech</a>
    <a href="javascript:;">Contact Us</a>
</div><?php /**PATH /Applications/MAMP/htdocs/stts/vendor/encore/laravel-admin/src/../resources/views/dashboard/title.blade.php ENDPATH**/ ?>