<?php echo e($msg, false); ?>

Click on the link..... 
<?php echo e($link, false); ?><?php /**PATH C:\Users\HP ENVY\Desktop\stts\resources\views/email_view.blade.php ENDPATH**/ ?>