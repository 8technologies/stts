<div class="alert alert-danger">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat beatae esse enim repellat voluptatibus autem facere
    dolorem asperiores, voluptate facilis deleniti numquam eos laboriosam animi eligendi? Itaque autem tempora
    provident?
    $message
    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
</div>