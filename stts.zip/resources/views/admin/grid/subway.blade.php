<div class="box box-solid">
    <div class="box-header with-border">
        <h3 class="box-title">Labels</h3>

        <div class="box-tools">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
        </div>
    </div>
    <div class="box-body no-padding">
        <ul class="nav nav-pills nav-stacked">
            <li><a href="/demo/subway/cities"><i class="fa fa-map-o text-red"></i> Cities</a></li>
            <li><a href="/demo/subway/lines"><i class="fa fa-train text-yellow"></i> Lines</a></li>
            <li><a href="/demo/subway/stops"><i class="fa fa-instagram text-light-blue"></i> Stops</a></li>
        </ul>
    </div>
    <!-- /.box-body -->
</div>