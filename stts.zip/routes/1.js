document.addEventListener("DOMContentLoaded", function() {
    alert("romina");
    $('#providers').hide();
});